# Calamares corresponding sources for Bitcoin Core Vault v0.4.0

Package: calamares 3.3.14-1+corevault4 (Debian 13, amd64).

This companion preserves the actual archived source used for the November 1
main-executable rebuild and the verified published corresponding sources for
the unchanged corevault3 package payload. It also contains exact frozen patch
inputs, Debian originals and original license texts.

The v4 binary package was made by replacing only /usr/bin/calamares in the
verified v3 package. Its packaged changelog still says corevault3. The original
compiler-reuse record and build procedure are retained under historical/.
No compiler, package installation or VM was run to prepare this companion;
no byte-identical binary rebuild or recovered historical buildinfo is claimed.

historical/patched-calamares-main-source.tar.gz contains the actual complete
patched source tree with its Debian build controls. The independent source
check reapplied the exact frozen patch to the verified Debian originals and
matched every archived file by SHA-256. Only src/calamares/CalamaresWindow.cpp
differs from the v3 C++ source. The base-v3 archive supplies the full source
for all unchanged binaries, their patches and original reconstruction record.

To inspect the v4 tree, extract the historical archive into an empty directory.
To rebuild the package from source on a dedicated Debian 13 builder, install
Debian's build dependencies for calamares 3.3.14-1 and use its debian/rules or
dpkg-buildpackage from that tree. The exact original partial-rebuild/repack
procedure is historical/compile-calamares-guest.py; its machine-specific paths
must be adapted in a dedicated builder. The matching base v3 binary package is
identified by SHA-256 in PROVENANCE.json. A full source build may differ from
the historical binary package; this companion does not assert reproducibility.

upstream/ preserves original Debian source files byte-for-byte. Their recorded
SHA-256 and .dsc members were checked; this preparation does not assert a new
independent OpenPGP authentication of the original Debian signer.
Per-file upstream/Debian license notices remain authoritative. The publication
of this companion on 2026-11-09 does not change historical modification dates.
