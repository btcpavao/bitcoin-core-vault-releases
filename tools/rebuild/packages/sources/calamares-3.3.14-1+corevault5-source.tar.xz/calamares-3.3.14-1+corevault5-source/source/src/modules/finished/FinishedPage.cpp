#include <QVBoxLayout>
#include <QCoreApplication>
#include <QVariant>
/* === This file is part of Calamares - <https://calamares.io> ===
 *
 *   SPDX-FileCopyrightText: 2014-2015 Teo Mrnjavac <teo@kde.org>
 *   SPDX-FileCopyrightText: 2017-2018 Adriaan de Groot <groot@kde.org>
 *   SPDX-FileCopyrightText: 2019 Collabora Ltd <arnaud.ferraris@collabora.com>
 *   SPDX-License-Identifier: GPL-3.0-or-later
 *
 *   Calamares is Free Software: see the License-Identifier above.
 *
 */

#include "FinishedPage.h"

#include "Config.h"
#include "ui_FinishedPage.h"

#include "Branding.h"
#include "Settings.h"
#include "compat/CheckBox.h"
#include "utils/Retranslator.h"

#include <QFocusEvent>


FinishedPage::FinishedPage( Config* config, QWidget* parent )
    : QWidget( parent )
    , ui( new Ui::FinishedPage )
{
    ui->setupUi( this );
    // CORE_VAULT_VISUAL_POLISH_V3: text immediately followed by the shared restart row.
    while (auto* item=ui->verticalLayout->takeAt(0)) {
        if (auto* nested=item->layout()) { delete nested; }
        else { delete item; }
    }
    ui->verticalLayout->setContentsMargins(0,0,0,0);
    ui->verticalLayout->setSpacing(0);
    ui->verticalLayout->addWidget(ui->mainText);
    ui->mainText->setAlignment(Qt::AlignCenter);
    ui->mainText->setWordWrap(true);

    ui->restartCheckBox->hide(); // CORE_OFFLINE_INTEGRATION

    ui->mainText->setAlignment( Qt::AlignCenter );
    ui->mainText->setWordWrap( true );
    ui->mainText->setOpenExternalLinks( true );

    connect( config,
             &Config::restartModeChanged,
             [ this ]( Config::RestartMode )
             {
                 ui->restartCheckBox->hide();
                 ui->restartCheckBox->setEnabled( false );
             } );
    connect( config, &Config::restartNowWantedChanged, ui->restartCheckBox, &QCheckBox::setChecked );
    connect( ui->restartCheckBox,
             Calamares::checkBoxStateChangedSignal,
             [ config ]( Calamares::checkBoxStateType state )
             { config->setRestartNowWanted( state != Calamares::checkBoxUncheckedValue ); } );

    CALAMARES_RETRANSLATE_SLOT( &FinishedPage::retranslate );
}

void
FinishedPage::focusInEvent( QFocusEvent* e )
{
    e->accept();
}

void
FinishedPage::onInstallationFailed( const QString& message, const QString& details )
{
    QCoreApplication::instance()->setProperty("coreVaultInstallationFailed", true);
    m_failure = !message.isEmpty() ? message : details;
    retranslate();
}

void
FinishedPage::retranslate()
{

    ui->retranslateUi(this);
    ui->restartCheckBox->hide();
    if (!m_failure.has_value()) {
        ui->mainText->setText(QStringLiteral(
            "<p style='font-size:42px;color:#4caf50;margin:0'>&#10003;</p>"
            "<p style='font-size:28px;font-weight:600;margin-top:8px;margin-bottom:14px'>Bitcoin Core Vault is ready.</p>"
            "<p>The installation completed successfully.<br/>"
            "Restart this computer to open Bitcoin Core Vault.</p>"));
    } else {
        ui->mainText->setText(tr(
            "<h1>Installation failed.</h1><p>Bitcoin Core Vault was not installed.</p><p>%1</p>")
            .arg(m_failure.value().toHtmlEscaped()));
    }
}
