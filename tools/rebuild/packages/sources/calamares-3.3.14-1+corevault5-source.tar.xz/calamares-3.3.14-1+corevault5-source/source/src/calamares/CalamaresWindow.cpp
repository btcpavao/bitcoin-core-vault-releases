#include <QResizeEvent>
#include <QShowEvent>
#include <QStyle>
#include <QStackedWidget>
#include <QCoreApplication>
#include <QVariant>
#include <QTimer>
/* === This file is part of Calamares - <https://calamares.io> ===
 *
 *   SPDX-FileCopyrightText: 2014-2015 Teo Mrnjavac <teo@kde.org>
 *   SPDX-FileCopyrightText: 2017-2018 Adriaan de Groot <groot@kde.org>
 *   SPDX-FileCopyrightText: 2018 Raul Rodrigo Segura (raurodse)
 *   SPDX-FileCopyrightText: 2019 Collabora Ltd <arnaud.ferraris@collabora.com>
 *   SPDX-FileCopyrightText: 2020 Anubhav Choudhary <ac.10edu@gmail.com>
 *   SPDX-License-Identifier: GPL-3.0-or-later
 *
 *   Calamares is Free Software: see the License-Identifier above.
 *
 */

#include "CalamaresWindow.h"

#include "Branding.h"
#include "CalamaresConfig.h"
#include "DebugWindow.h"
#include "Settings.h"
#include "ViewManager.h"
#include "progresstree/ProgressTreeView.h"
#include "utils/Gui.h"
#include "utils/Logger.h"
#include "utils/Qml.h"
#include "utils/Retranslator.h"

#include <QApplication>
#include <QBoxLayout>
#include <QCloseEvent>
#if QT_VERSION < QT_VERSION_CHECK( 6, 0, 0 )
#include <QDesktopWidget>
#endif
#include <QFile>
#include <QFileInfo>
#include <QLabel>
#ifdef WITH_QML
#include <QQmlContext>
#include <QQmlEngine>
#include <QQuickItem>
#include <QQuickWidget>
#endif
#include <QTreeView>


// CORE_VAULT_VISUAL_POLISH_V3
// Header/footer never borrow space from a page. Existing controls keep their signals.
static void coreVaultSizeNavigationSlots(QWidget* navigation,int step);
class CoreVaultWizardSurface final : public QWidget
{
public:
    QWidget *header, *page, *nav, *footer;
    int step = 0;
    CoreVaultWizardSurface(QWidget* parent, QWidget* h, QWidget* p, QWidget* n)
        : QWidget(parent), header(h), page(p), nav(n), footer(new QWidget(this))
    {
        setObjectName(QStringLiteral("coreVaultWizardSurface"));
        for (auto* w : {header, page, nav}) w->setParent(this);
        page->setMinimumSize(0,0);
        if (page->layout()) page->layout()->setSizeConstraint(QLayout::SetNoConstraint);
        auto* f = new QVBoxLayout(footer);
        f->setContentsMargins(0,0,0,0); f->setSpacing(4);
        auto* logo = new QLabel(footer);
        logo->setObjectName(QStringLiteral("coreVaultFooterLogo"));
        logo->setAlignment(Qt::AlignCenter);
        logo->setPixmap(QPixmap("/etc/calamares/branding/core-offline/debian.png")
                        .scaled(40,49,Qt::KeepAspectRatio,Qt::SmoothTransformation));
        f->addWidget(logo);
        auto* text = new QLabel(QStringLiteral("Powered by Debian GNU/Linux"),footer);
        text->setObjectName(QStringLiteral("coreOfflineDebianCredit"));
        text->setAlignment(Qt::AlignCenter); f->addWidget(text);
        header->show(); page->show(); nav->show(); footer->show();
    }
    void setStep(int s) { step=s; arrange(); QTimer::singleShot(0,this,[this](){arrange();}); }
    void arrange()
    {
        const bool compact = height()<680;
        // Recompute only presentation when the viewport enters the compact mode.
        // Scoped QSS uses this property to keep the complete Review readable.
        if (!property("coreVaultCompact").isValid()
            || property("coreVaultCompact").toBool()!=compact) {
            setProperty("coreVaultCompact",compact);
            const QString ownSheet=styleSheet();
            setStyleSheet(QStringLiteral(" ")); setStyleSheet(ownSheet);
            // Clear the selector cache on the property-bearing ancestor first.
            style()->unpolish(this); style()->polish(this);
            for (auto* w : findChildren<QWidget*>()) {
                w->style()->unpolish(w); w->style()->polish(w); w->updateGeometry();
            }
        }
        // CORE_VAULT_REGISTERED_PAGE_MARGINS_V4
        // ViewManager assigns style-default margins after module construction.
        // Normalize the registered page here, including Partition's stacked wrapper.
        if (step<=2) {
            // Qt style polishing resets button minimum sizes. Restore the shared slots afterwards.
            coreVaultSizeNavigationSlots(nav,step);
            auto* views=page->findChild<QStackedWidget*>(QStringLiteral("viewManagerStack"));
            if (views && views->currentWidget() && views->currentWidget()->layout())
                views->currentWidget()->layout()->setContentsMargins(0,0,0,0);
        }
        const int edge = compact ? 12 : 22;
        const int hh = compact ? qMax(132,header->minimumSizeHint().height()) : 162;
        const int fh = 70;
        const int cw = qMin(944, qMax(1,width()-2*(compact?20:32)));
        const int x = (width()-cw)/2;
        header->setFixedHeight(hh);
        header->setGeometry(0,edge,width(),hh);
        footer->setGeometry(0,height()-edge-fh,width(),fh);
        const int top = edge+hh+(compact?4:10);
        const int bottom = height()-edge-fh-(compact?4:12);
        const int room = qMax(1,bottom-top);
        if (step==3) {
            nav->hide(); page->setGeometry(x,top,cw,room); return;
        }
        nav->show();
        const int navh=compact?32:34, gap=compact?8:12;
        // The first three pages share one rectangle and one navigation baseline.
        // Short viewports cap the region; their content uses the compact QSS.
        const int wanted=step>=4 ? 190 : 432;
        const int ph=qMin(wanted,qMax(1,room-navh-gap));
        // Forms start below the stepper. The finished message/button are a centered group.
        const int offset=step>=4 ? qMax(0,(room-ph-navh-gap)/2) : 0;
        page->setGeometry(x,top+offset,cw,ph);
        nav->setGeometry(x,top+offset+ph+gap,cw,navh);
    }
protected:
    void resizeEvent(QResizeEvent* e) override { QWidget::resizeEvent(e); arrange(); }
    void showEvent(QShowEvent* e) override {
        QWidget::showEvent(e); QTimer::singleShot(0,this,[this](){arrange();});
    }
};

// Shared slots retain their width when Back is unavailable on Keyboard.
static void coreVaultInstallNavigationSlots(QWidget* navigation, QBoxLayout* row)
{
    auto* back=navigation->findChild<QPushButton*>(QStringLiteral("view-button-back"));
    auto* next=navigation->findChild<QPushButton*>(QStringLiteral("view-button-next"));
    auto* quit=navigation->findChild<QPushButton*>(QStringLiteral("view-button-cancel"));
    if (!back || !next || !quit) return;
    while (auto* item=row->takeAt(0)) delete item; // Controls and their signals survive.
    row->setContentsMargins(0,0,0,0); row->setSpacing(10);
    row->addStretch();
    const char* names[]={"coreVaultBackSlot","coreVaultPrimarySlot","coreVaultCancelSlot"};
    int i=0;
    for (auto* button : {back,next,quit}) {
        auto* slot=new QWidget(navigation);
        slot->setObjectName(QString::fromLatin1(names[i++]));
        slot->setFixedHeight(32);
        auto* layout=new QHBoxLayout(slot);
        layout->setContentsMargins(0,0,0,0); layout->setSpacing(0);
        layout->addWidget(button,0,Qt::AlignCenter);
        row->addWidget(slot,0,Qt::AlignCenter);
    }
    row->addStretch();
}
static void coreVaultSizeNavigationSlots(QWidget* navigation,int step)
{
    auto* back=navigation->findChild<QPushButton*>(QStringLiteral("view-button-back"));
    auto* next=navigation->findChild<QPushButton*>(QStringLiteral("view-button-next"));
    auto* quit=navigation->findChild<QPushButton*>(QStringLiteral("view-button-cancel"));
    auto* backSlot=navigation->findChild<QWidget*>(QStringLiteral("coreVaultBackSlot"));
    auto* primarySlot=navigation->findChild<QWidget*>(QStringLiteral("coreVaultPrimarySlot"));
    auto* cancelSlot=navigation->findChild<QWidget*>(QStringLiteral("coreVaultCancelSlot"));
    if (!back || !next || !quit || !backSlot || !primarySlot || !cancelSlot) return;
    for (auto* button : {back,next,quit}) button->ensurePolished();
    const int primaryWidth=qMax(194,
        next->fontMetrics().horizontalAdvance(QStringLiteral("Erase drive and install"))+30);
    const int quitWidth=step>=4
        ? qMax(104,quit->fontMetrics().horizontalAdvance(quit->text().remove('&'))+30) : 104;
    back->setFixedSize(104,32); next->setFixedSize(primaryWidth,32); quit->setFixedSize(quitWidth,32);
    backSlot->setFixedWidth(104); primarySlot->setFixedWidth(primaryWidth);
    cancelSlot->setFixedWidth(quitWidth);
    backSlot->setVisible(step<=2); primarySlot->setVisible(step<=2);
    cancelSlot->setVisible(step!=3);
}

static QSize
desktopSize( QWidget* w )
{
#if QT_VERSION < QT_VERSION_CHECK( 6, 0, 0 )
    return qApp->desktop()->availableGeometry( w ).size();
#else
    return w->screen()->availableGeometry().size();
#endif
}

static inline int
windowDimensionToPixels( const Calamares::Branding::WindowDimension& u )
{
    if ( !u.isValid() )
    {
        return 0;
    }
    if ( u.unit() == Calamares::Branding::WindowDimensionUnit::Pixies )
    {
        return static_cast< int >( u.value() );
    }
    if ( u.unit() == Calamares::Branding::WindowDimensionUnit::Fonties )
    {
        return static_cast< int >( u.value() * Calamares::defaultFontHeight() );
    }
    return 0;
}

/** @brief Expected orientation of the panels, based on their side
 *
 * Panels on the left and right are expected to be "vertical" style,
 * top and bottom should be "horizontal bars". This function maps
 * the sides to expected orientation.
 */
static inline Qt::Orientation
orientation( const Calamares::Branding::PanelSide s )
{
    using Side = Calamares::Branding::PanelSide;
    return ( s == Side::Left || s == Side::Right ) ? Qt::Orientation::Vertical : Qt::Orientation::Horizontal;
}

/** @brief Get a button-sized icon. */
static inline QPixmap
getButtonIcon( const QString& name )
{
    return Calamares::Branding::instance()->image( name, QSize( 22, 22 ) );
}

static inline void
setButtonIcon( QPushButton* button, const QString& name )
{
    auto icon = getButtonIcon( name );
    if ( button && !icon.isNull() )
    {
        button->setIcon( icon );
    }
}

static QWidget*
getWidgetSidebar( Calamares::DebugWindowManager* debug,
                  Calamares::ViewManager* viewManager,
                  QWidget* parent,
                  Qt::Orientation,
                  int desiredWidth )
{
    // CORE_OFFLINE_INTEGRATION: Bitcoin Core Vault product header + three-step installer progress.
    auto* box = new QWidget(parent);
    auto* layout = new QVBoxLayout(box);
    layout->setContentsMargins(16, 0, 16, 0);
    layout->setSpacing(4);

    auto* logo = new QLabel(box);
    logo->setAlignment(Qt::AlignCenter);
    logo->setPixmap(QPixmap("/etc/calamares/branding/core-offline/bitcoin.png").scaled(
        44, 44, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    layout->addWidget(logo);

    auto* title = new QLabel(QStringLiteral("Bitcoin Core Vault"), box);
    title->setAlignment(Qt::AlignCenter);
    title->setObjectName(QStringLiteral("coreOfflineProductTitle"));
    layout->addWidget(title);

    auto* subtitle = new QLabel(QStringLiteral("Installer"), box);
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setObjectName(QStringLiteral("coreOfflineProductSubtitle"));
    layout->addWidget(subtitle);

    auto* steps = new QHBoxLayout;
    steps->setContentsMargins(0, 4, 0, 0);
    steps->setSpacing(8);
    auto* step1 = new QLabel(box);
    auto* step2 = new QLabel(box);
    auto* step3 = new QLabel(box);
    auto* sep1 = new QLabel(QStringLiteral("────────"), box);
    auto* sep2 = new QLabel(QStringLiteral("────────"), box);
    for (auto* s : { step1, step2, step3 }) {
        s->setAlignment(Qt::AlignCenter);
        s->setFixedWidth(124);
    }
    for (auto* sep : { sep1, sep2 }) {
        sep->setAlignment(Qt::AlignCenter);
        sep->setFixedWidth(64);
    }
    sep1->setObjectName(QStringLiteral("coreOfflineStepSeparator"));
    sep2->setObjectName(QStringLiteral("coreOfflineStepSeparator"));
    steps->addStretch(); steps->addWidget(step1); steps->addWidget(sep1);
    steps->addWidget(step2); steps->addWidget(sep2); steps->addWidget(step3); steps->addStretch();
    layout->addLayout(steps);

    auto* vm = Calamares::ViewManager::instance();
    auto updateSteps = [vm, step1, step2, step3]() {
        const int current = vm->currentStepIndex();
        auto style = [current](QLabel* label, int index, const QString& name) {
            if (current > index) {
                label->setText(QStringLiteral("✓  ") + name);
                label->setStyleSheet(QStringLiteral("QLabel { color:#ffffff; padding:6px 10px; font-weight:600; }"));
            } else if (current == index) {
                label->setText(QString::number(index + 1) + QStringLiteral("  ") + name);
                label->setStyleSheet(QStringLiteral("QLabel { background:#ffffff; color:#000000; border-radius:13px; padding:6px 12px; font-weight:700; }"));
            } else {
                label->setText(QString::number(index + 1) + QStringLiteral("  ") + name);
                label->setStyleSheet(QStringLiteral("QLabel { color:#777777; padding:6px 10px; }"));
            }
        };
        if (current >= 3) {
            step1->setText(QStringLiteral("✓  Keyboard"));
            step2->setText(QStringLiteral("✓  Disk"));
            step3->setText(QStringLiteral("✓  Review"));
            for (auto* s : { step1, step2, step3 }) {
                s->setStyleSheet(QStringLiteral("QLabel { color:#ffffff; padding:6px 10px; font-weight:600; }"));
            }
        } else {
            style(step1, 0, QStringLiteral("Keyboard"));
            style(step2, 1, QStringLiteral("Disk"));
            style(step3, 2, QStringLiteral("Review"));
        }
    };
    QObject::connect(vm, &Calamares::ViewManager::currentStepChanged, box, updateSteps);
    updateSteps();
    box->setFixedHeight(162);
    return box;
}

static QWidget*
getWidgetNavigation( Calamares::DebugWindowManager*,
                     Calamares::ViewManager* viewManager,
                     QWidget* parent,
                     Qt::Orientation,
                     int )
{
    QWidget* navigation = new QWidget( parent );
    QBoxLayout* bottomLayout = new QHBoxLayout;
    bottomLayout->addStretch();

    // Create buttons and sets an initial icon; the icons may change
    {
        auto* back = new QPushButton(
            getButtonIcon( QStringLiteral( "go-previous" ) ),
            QCoreApplication::translate( CalamaresWindow::staticMetaObject.className(), "&Back", "@button" ),
            navigation );
        back->setObjectName( "view-button-back" );
        back->setEnabled( viewManager->backEnabled() );
        QObject::connect( back, &QPushButton::clicked, viewManager, &Calamares::ViewManager::back );
        QObject::connect( viewManager, &Calamares::ViewManager::backEnabledChanged, back, &QPushButton::setEnabled );
        QObject::connect( viewManager, &Calamares::ViewManager::backLabelChanged, back, &QPushButton::setText );
        QObject::connect(
            viewManager, &Calamares::ViewManager::backIconChanged, [ = ]( QString n ) { setButtonIcon( back, n ); } );
        QObject::connect(
            viewManager, &Calamares::ViewManager::backAndNextVisibleChanged, back, &QPushButton::setVisible );
        bottomLayout->addWidget( back );
    }
    {
        auto* next = new QPushButton(
            getButtonIcon( QStringLiteral( "go-next" ) ),
            QCoreApplication::translate( CalamaresWindow::staticMetaObject.className(), "&Next", "@button" ),
            navigation );
        next->setObjectName( "view-button-next" );
        next->setEnabled( viewManager->nextEnabled() );
        QObject::connect( next, &QPushButton::clicked, viewManager, &Calamares::ViewManager::next );
        QObject::connect( viewManager, &Calamares::ViewManager::nextEnabledChanged, next, &QPushButton::setEnabled );
        QObject::connect( viewManager, &Calamares::ViewManager::nextLabelChanged, next, &QPushButton::setText );
        QObject::connect(
            viewManager, &Calamares::ViewManager::nextIconChanged, [ = ]( QString n ) { setButtonIcon( next, n ); } );
        QObject::connect(
            viewManager, &Calamares::ViewManager::backAndNextVisibleChanged, next, &QPushButton::setVisible );
        bottomLayout->addWidget( next );
    }
    bottomLayout->addSpacing( 12 );
    {
        auto* quit = new QPushButton(
            getButtonIcon( QStringLiteral( "dialog-cancel" ) ),
            QCoreApplication::translate( CalamaresWindow::staticMetaObject.className(), "&Cancel", "@button" ),
            navigation );
        quit->setObjectName( "view-button-cancel" );
        QObject::connect( quit, &QPushButton::clicked, viewManager, &Calamares::ViewManager::quit );
        QObject::connect( viewManager, &Calamares::ViewManager::quitEnabledChanged, quit, &QPushButton::setEnabled );
        QObject::connect( viewManager, &Calamares::ViewManager::quitLabelChanged, quit, &QPushButton::setText );
        QObject::connect(
            viewManager, &Calamares::ViewManager::quitIconChanged, [ = ]( QString n ) { setButtonIcon( quit, n ); } );
        QObject::connect( viewManager, &Calamares::ViewManager::quitTooltipChanged, quit, &QPushButton::setToolTip );
        QObject::connect( viewManager, &Calamares::ViewManager::quitVisibleChanged, quit, &QPushButton::setVisible );
        bottomLayout->addWidget( quit );
    }

    bottomLayout->setContentsMargins( 0, 0, 6, 6 );
    // CORE_VAULT_VISUAL_POLISH_V4: stable slots; footer is independent.
    coreVaultInstallNavigationSlots(navigation,bottomLayout);
    navigation->setLayout(bottomLayout);

    auto updateNavigation = [viewManager, navigation]() {
        auto* back = navigation->findChild<QPushButton*>(QStringLiteral("view-button-back"));
        auto* next = navigation->findChild<QPushButton*>(QStringLiteral("view-button-next"));
        auto* quit = navigation->findChild<QPushButton*>(QStringLiteral("view-button-cancel"));
        if (!back || !next || !quit) return;
        for (auto* button : { back, next, quit }) {
            button->setMinimumSize(0,0);
            button->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
        }
        quit->setStyleSheet(QString());
        const int i = viewManager->currentStepIndex();
        if (i == 0) {
            back->hide(); next->show(); next->setText(QStringLiteral("Continue")); quit->show(); quit->setText(QStringLiteral("Cancel"));
        } else if (i == 1) {
            back->show(); next->show(); next->setText(QStringLiteral("Continue")); quit->show(); quit->setText(QStringLiteral("Cancel"));
        } else if (i == 2) {
            back->show(); next->show(); next->setText(QStringLiteral("Erase drive and install")); quit->show(); quit->setText(QStringLiteral("Cancel"));
        } else if (i == 3) {
            back->hide(); next->hide(); quit->hide();
        } else if (i >= 4) {
            back->hide();
            next->hide();
            quit->show();
            quit->setText(QCoreApplication::instance()->property("coreVaultInstallationFailed").toBool() ? QStringLiteral("Close installer") : QStringLiteral("Restart into Bitcoin Core Vault"));
            quit->setMinimumWidth(220);
            quit->setStyleSheet(QStringLiteral(
                "QPushButton { background:#ffffff; color:#000000; border:1px solid #ffffff; "
                "border-radius:6px; padding:0px 12px; font-size:13px; font-weight:600; } "
                "QPushButton:hover { background:#e7e7e7; border-color:#e7e7e7; } "
                "QPushButton:focus { border:2px solid #f7931a; }"));
        }

        for (auto* button : {back,next,quit}) button->setIcon(QIcon());
        coreVaultSizeNavigationSlots(navigation,i);
    };
    QObject::connect(viewManager, &Calamares::ViewManager::currentStepChanged, navigation, [navigation, updateNavigation]() { updateNavigation(); QTimer::singleShot(0, navigation, updateNavigation); });
    // Later ViewManager visibility signals must not bring back a disabled
    // Cancel button while jobs are running. No enabled state is changed here.
    QObject::connect(viewManager, &Calamares::ViewManager::quitVisibleChanged,
                     navigation, [viewManager, navigation](bool) {
        if (viewManager->currentStepIndex() == 3)
            if (auto* q = navigation->findChild<QPushButton*>(QStringLiteral("view-button-cancel"))) q->hide();
    });

    QObject::connect(viewManager, &Calamares::ViewManager::nextLabelChanged, navigation, [updateNavigation](const QString&) { updateNavigation(); });
    QObject::connect(viewManager, &Calamares::ViewManager::quitLabelChanged, navigation, [updateNavigation](const QString&) { updateNavigation(); });
    QObject::connect(viewManager, &Calamares::ViewManager::backLabelChanged, navigation, [updateNavigation](const QString&) { updateNavigation(); });
    updateNavigation();
    return navigation;
}

#ifdef WITH_QML

static inline void
setDimension( QQuickWidget* w, Qt::Orientation o, int desiredWidth )
{
    w->setSizePolicy( o == Qt::Orientation::Vertical ? QSizePolicy::MinimumExpanding : QSizePolicy::Expanding,
                      o == Qt::Orientation::Horizontal ? QSizePolicy::MinimumExpanding : QSizePolicy::Expanding );
    if ( o == Qt::Orientation::Vertical )
    {
        w->setFixedWidth( desiredWidth );
    }
    else
    {
        // If the QML itself sets a height, use that, otherwise go to 48 pixels
        // which seems to match what the widget navigation would use for height
        // (with *my* specific screen, style, etc. so YMMV).
        //
        // Bound between (16, 64) with a default of 48.
        qreal minimumHeight = qBound( qreal( 16 ), w->rootObject() ? w->rootObject()->height() : 48, qreal( 64 ) );
        w->setMinimumHeight( int( minimumHeight ) );
        w->setFixedHeight( int( minimumHeight ) );
    }
    w->setResizeMode( QQuickWidget::SizeRootObjectToView );
}

static QWidget*
getQmlSidebar( Calamares::DebugWindowManager* debug,
               Calamares::ViewManager*,
               QWidget* parent,
               Qt::Orientation o,
               int desiredWidth )
{
    Calamares::registerQmlModels();
    QQuickWidget* w = new QQuickWidget( parent );
    if ( debug )
    {
        w->engine()->rootContext()->setContextProperty( "debug", debug );
    }

    w->setSource(
        QUrl( Calamares::searchQmlFile( Calamares::QmlSearch::Both, QStringLiteral( "calamares-sidebar" ) ) ) );
    setDimension( w, o, desiredWidth );
    return w;
}

static QWidget*
getQmlNavigation( Calamares::DebugWindowManager* debug,
                  Calamares::ViewManager*,
                  QWidget* parent,
                  Qt::Orientation o,
                  int desiredWidth )
{
    Calamares::registerQmlModels();
    QQuickWidget* w = new QQuickWidget( parent );
    if ( debug )
    {
        w->engine()->rootContext()->setContextProperty( "debug", debug );
    }
    w->setSource(
        QUrl( Calamares::searchQmlFile( Calamares::QmlSearch::Both, QStringLiteral( "calamares-navigation" ) ) ) );
    setDimension( w, o, desiredWidth );
    return w;
}
#else
// Bogus to keep the linker happy
//
// Calls to flavoredWidget() still refer to these *names*
// even if they are subsequently not used.
static QWidget*
getQmlSidebar( Calamares::DebugWindowManager*,
               Calamares::ViewManager*,
               QWidget* parent,
               Qt::Orientation,
               int desiredWidth )
{
    return nullptr;
}
static QWidget*
getQmlNavigation( Calamares::DebugWindowManager*,
                  Calamares::ViewManager*,
                  QWidget* parent,
                  Qt::Orientation,
                  int desiredWidth )
{
    return nullptr;
}
#endif

/**@brief Picks one of two methods to call
 *
 * Calls method (member function) @p widget or @p qml with arguments @p a
 * on the given window, based on the flavor.
 */
template < typename widgetMaker, typename... args >
QWidget*
flavoredWidget( Calamares::Branding::PanelFlavor flavor,
                Qt::Orientation o,
                Calamares::DebugWindowManager* w,
                QWidget* parent,
                widgetMaker widget,
                widgetMaker qml,  // Only if WITH_QML is on
                args... a )
{
#ifndef WITH_QML
    Q_UNUSED( qml )
#endif
    auto* viewManager = Calamares::ViewManager::instance();
    switch ( flavor )
    {
    case Calamares::Branding::PanelFlavor::Widget:
        return widget( w, viewManager, parent, o, a... );
#ifdef WITH_QML
    case Calamares::Branding::PanelFlavor::Qml:
        return qml( w, viewManager, parent, o, a... );
#endif
    case Calamares::Branding::PanelFlavor::None:
        return nullptr;
    }
    __builtin_unreachable();
}

/** @brief Adds widgets to @p layout if they belong on this @p side
 */
static inline void
insertIf( QBoxLayout* layout,
          Calamares::Branding::PanelSide side,
          QWidget* first,
          Calamares::Branding::PanelSide firstSide )
{
    if ( first && side == firstSide )
    {
        layout->addWidget( first );
    }
}

CalamaresWindow::CalamaresWindow( QWidget* parent )
    : QWidget( parent )
    , m_debugManager( new Calamares::DebugWindowManager( this ) )
    , m_viewManager( nullptr )
{
    installEventFilter( Calamares::Retranslator::instance() );

    // If we can never cancel, don't show the window-close button
    if ( Calamares::Settings::instance()->disableCancel() )
    {
        setWindowFlag( Qt::WindowCloseButtonHint, false );
    }

    // %1 is the distribution name
    CALAMARES_RETRANSLATE( const auto* branding = Calamares::Branding::instance();
                           setWindowTitle( Calamares::Settings::instance()->isSetupMode()
                                               ? tr( "%1 Setup Program" ).arg( branding->productName() )
                                               : tr( "%1 Installer" ).arg( branding->productName() ) ); );

    const Calamares::Branding* const branding = Calamares::Branding::instance();
    using ImageEntry = Calamares::Branding::ImageEntry;

    using Calamares::windowMinimumHeight;
    using Calamares::windowMinimumWidth;
    using Calamares::windowPreferredHeight;
    using Calamares::windowPreferredWidth;

    using PanelSide = Calamares::Branding::PanelSide;

    // Needs to match what's checked in DebugWindow
    this->setObjectName( "mainApp" );

    QSize availableSize = desktopSize( this );
    QSize minimumSize( qBound( windowMinimumWidth, availableSize.width(), windowPreferredWidth ),
                       qBound( windowMinimumHeight, availableSize.height(), windowPreferredHeight ) );
    setMinimumSize( minimumSize );

    cDebug() << "Available desktop" << availableSize << "minimum size" << minimumSize;

    auto brandingSizes = branding->windowSize();

    int w = qBound( minimumSize.width(), windowDimensionToPixels( brandingSizes.first ), availableSize.width() );
    int h = qBound( minimumSize.height(), windowDimensionToPixels( brandingSizes.second ), availableSize.height() );

    cDebug() << Logger::SubEntry << "Proposed window size:" << w << h;
    resize( w, h );

    QWidget* baseWidget = this;
    if ( !( branding->imagePath( ImageEntry::ProductWallpaper ).isEmpty() ) )
    {
        QWidget* label = new QWidget( this );
        QVBoxLayout* l = new QVBoxLayout;
        Calamares::unmarginLayout( l );
        l->addWidget( label );
        setLayout( l );
        label->setObjectName( "backgroundWidget" );
        label->setStyleSheet(
            QStringLiteral( "#backgroundWidget { background-image: url(%1); background-repeat: repeat-xy; }" )
                .arg( branding->imagePath( ImageEntry::ProductWallpaper ) ) );

        baseWidget = label;
    }

    m_viewManager = Calamares::ViewManager::instance( baseWidget );
    if ( branding->windowExpands() )
    {
        connect( m_viewManager, &Calamares::ViewManager::ensureSize, this, &CalamaresWindow::ensureSize );
    }
    // NOTE: Although the ViewManager has a signal cancelEnabled() that
    //       signals when the state of the cancel button changes (in
    //       particular, to disable cancel during the exec phase),
    //       we don't connect to it here. Changing the window flag
    //       for the close button causes uncomfortable window flashing
    //       and requires an extra show() (at least with KWin/X11) which
    //       is too annoying. Instead, leave it up to ignoring-the-quit-
    //       event, which is also the ViewManager's responsibility.

    auto* header=getWidgetSidebar(m_debugManager,m_viewManager,baseWidget,Qt::Horizontal,0);
    auto* navigation=getWidgetNavigation(m_debugManager,m_viewManager,baseWidget,Qt::Horizontal,0);
    auto* shell=new CoreVaultWizardSurface(baseWidget,header,m_viewManager->centralWidget(),navigation);
    auto* mainLayout=new QVBoxLayout;
    mainLayout->setContentsMargins(0,0,0,0); mainLayout->setSpacing(0); mainLayout->addWidget(shell);
    m_viewManager->setPanelSides(Qt::Horizontal);
    QObject::connect(m_viewManager,&Calamares::ViewManager::currentStepChanged,shell,
        [this,shell](){shell->setStep(m_viewManager->currentStepIndex());});
    shell->setStep(m_viewManager->currentStepIndex());
    baseWidget->setLayout(mainLayout);
    setStyleSheet( Calamares::Branding::instance()->stylesheet() );
}

void
CalamaresWindow::ensureSize( QSize size )
{
    auto mainGeometry = this->geometry();
    QSize availableSize = desktopSize( this );

    // We only care about vertical sizes that are big enough
    int embiggenment = qMax( 0, size.height() - m_viewManager->centralWidget()->size().height() );
    if ( embiggenment < 6 )
    {
        return;
    }

    auto h = qBound( 0, mainGeometry.height() + embiggenment, availableSize.height() );
    auto w = this->size().width();

    resize( w, h );
}

void
CalamaresWindow::closeEvent( QCloseEvent* event )
{
    if ( m_viewManager )
    {
        m_viewManager->quit();
        // If it didn't actually exit, eat the event to ignore close
        event->ignore();
    }
    else
    {
        event->accept();
#if QT_VERSION < QT_VERSION_CHECK( 6, 0, 0 )
        QApplication::quit();
#else
        QApplication::exit( EXIT_SUCCESS );
#endif
    }
}
