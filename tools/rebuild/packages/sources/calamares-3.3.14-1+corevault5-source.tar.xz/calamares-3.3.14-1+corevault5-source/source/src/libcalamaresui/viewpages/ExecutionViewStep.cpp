/* === This file is part of Calamares - <https://calamares.io> ===
 *
 *   SPDX-FileCopyrightText: 2014 Aurélien Gâteau <agateau@kde.org>
 *   SPDX-FileCopyrightText: 2014-2015 Teo Mrnjavac <teo@kde.org>
 *   SPDX-FileCopyrightText: 2018 Adriaan de Groot <groot@kde.org>
 *   SPDX-License-Identifier: GPL-3.0-or-later
 *
 *   Calamares is Free Software: see the License-Identifier above.
 *
 */

#include "ExecutionViewStep.h"

#include "Slideshow.h"

#include "Branding.h"
#include "CalamaresConfig.h"
#include "Job.h"
#include "JobQueue.h"
#include "Settings.h"
#include "ViewManager.h"
#include "modulesystem/Module.h"
#include "modulesystem/ModuleManager.h"
#include "utils/Dirs.h"
#include "utils/Gui.h"
#include "utils/Logger.h"
#include "utils/Retranslator.h"
#include "widgets/LogWidget.h"

#include <QAction>
#include <QDir>
#include <QHBoxLayout>
#include <QLabel>
#include <QPlainTextEdit>
#include <QPixmap>
#include <QProgressBar>
#include <QTabBar>
#include <QTabWidget>
#include <QToolBar>
#include <QToolButton>
#include <QVBoxLayout>
#include <QResizeEvent>
#include <QShowEvent>
#include <QTimer>

static Calamares::Slideshow*
makeSlideshow( QWidget* parent )
{
    const int api = Calamares::Branding::instance()->slideshowAPI();
    switch ( api )
    {
    case -1:
        return new Calamares::SlideshowPictures( parent );
#ifdef WITH_QML
    case 1:
        [[fallthrough]];
    case 2:
        return new Calamares::SlideshowQML( parent );
#endif
    default:
        cWarning() << "Unknown Branding slideshow API" << api;
        return new Calamares::SlideshowPictures( parent );
    }
}


// CORE_VAULT_VISUAL_POLISH_V3_PROGRESS
class CoreVaultExecutionSurface final : public QWidget
{
public:
    using QWidget::QWidget;
    QWidget* above=nullptr;
    QProgressBar* progress=nullptr;
    QSize sizeHint() const override { return QSize(820,180); }
    QSize minimumSizeHint() const override { return QSize(360,140); }
    void arrange() {
        if (!above || !progress) return;
        const int cw=qMin(820,qMax(1,width()-32));
        const int x=(width()-cw)/2;
        auto* l=above->layout();
        const int wh=l && l->hasHeightForWidth() ? l->totalHeightForWidth(cw) : -1;
        const int ah=qMax(1,wh>=0 ? wh : above->sizeHint().height());
        const int bh=24;
        const int desired=mapFrom(window(),window()->rect().center()).y();
        const int lo=ah+16+bh/2;
        const int hi=height()-bh/2-4;
        const int cy=hi>=lo ? qBound(lo,desired,hi) : lo;
        above->setGeometry(x,cy-bh/2-16-ah,cw,ah);
        progress->setGeometry(x,cy-bh/2,cw,bh);
    }
protected:
    void resizeEvent(QResizeEvent* e) override { QWidget::resizeEvent(e); arrange(); }
    void showEvent(QShowEvent* e) override {
        QWidget::showEvent(e); QTimer::singleShot(0,this,[this](){arrange();});
    }
};

namespace Calamares
{

ExecutionViewStep::ExecutionViewStep( QObject* parent )
    : ViewStep( parent )
    , m_widget( new CoreVaultExecutionSurface )
    , m_progressBar( new QProgressBar )
    , m_label( new QLabel )
    , m_slideshow( makeSlideshow( m_widget ) )
    , m_tab_widget( new QTabWidget )
    , m_log_widget( new LogWidget )
{

    m_widget->setObjectName("slideshow");
    auto* surface=static_cast<CoreVaultExecutionSurface*>(m_widget);
    m_progressBar->setParent(m_widget);
    m_progressBar->setObjectName("exec-progress");
    m_progressBar->setMaximum(10000);
    m_progressBar->setFormat(QStringLiteral("%p%"));
    m_progressBar->setAlignment(Qt::AlignCenter);
    m_progressBar->show();
    auto* above=new QWidget(m_widget);
    auto* l=new QVBoxLayout(above);
    l->setContentsMargins(0,0,0,0); l->setSpacing(12);
    auto* title=new QLabel(QStringLiteral("Installing Bitcoin Core Vault"),above);
    title->setObjectName("coreOfflineExecutionTitle");
    title->setAlignment(Qt::AlignCenter); title->setWordWrap(true);
    auto* description=new QLabel(QStringLiteral(
        "Please keep the computer powered on and the installation USB connected."),above);
    description->setObjectName("coreOfflineExecutionDescription");
    description->setAlignment(Qt::AlignCenter); description->setWordWrap(true);
    l->addWidget(title); l->addWidget(description);
    // Retain upstream diagnostic objects, but do not expose a status/log control in this view.
    m_label->setParent(m_widget); m_label->hide();
    m_tab_widget->setParent(m_widget);
    m_tab_widget->addTab(m_log_widget,QStringLiteral("Log"));
    m_tab_widget->hide();
    surface->above=above; surface->progress=m_progressBar;
    QTimer::singleShot(0,m_widget,[surface](){surface->arrange();});
    connect(JobQueue::instance(), &JobQueue::progress, this, &ExecutionViewStep::updateFromJobQueue);

}

QString
ExecutionViewStep::prettyName() const
{
    return Calamares::Settings::instance()->isSetupMode() ? tr( "Set Up", "@label" ) : tr( "Install", "@label" );
}

QWidget*
ExecutionViewStep::widget()
{
    return m_widget;
}

void
ExecutionViewStep::next()
{
}

void
ExecutionViewStep::back()
{
}

bool
ExecutionViewStep::isNextEnabled() const
{
    return false;
}

bool
ExecutionViewStep::isBackEnabled() const
{
    return false;
}

bool
ExecutionViewStep::isAtBeginning() const
{
    return true;
}

bool
ExecutionViewStep::isAtEnd() const
{
    return !JobQueue::instance()->isRunning();
}

void
ExecutionViewStep::onActivate()
{
    m_slideshow->widget()->hide(); // CORE_OFFLINE_INTEGRATION: branded progress panel replaces slideshow.

    const auto instanceDescriptors = Calamares::Settings::instance()->moduleInstances();

    JobQueue* queue = JobQueue::instance();
    for ( const auto& instanceKey : m_jobInstanceKeys )
    {
        const auto& moduleDescriptor = Calamares::ModuleManager::instance()->moduleDescriptor( instanceKey );
        Calamares::Module* module = Calamares::ModuleManager::instance()->moduleInstance( instanceKey );

        const auto instanceDescriptor
            = std::find_if( instanceDescriptors.constBegin(),
                            instanceDescriptors.constEnd(),
                            [ = ]( const Calamares::InstanceDescription& d ) { return d.key() == instanceKey; } );
        int weight = moduleDescriptor.weight();
        if ( instanceDescriptor != instanceDescriptors.constEnd() && instanceDescriptor->explicitWeight() )
        {
            weight = instanceDescriptor->weight();
        }
        weight = qBound( 1, weight, 100 );
        if ( module )
        {
            auto jl = module->jobs();
            if ( module->isEmergency() )
            {
                for ( auto& j : jl )
                {
                    j->setEmergency( true );
                }
            }
            queue->enqueue( weight, jl );
        }
    }

    queue->start();
}

JobList
ExecutionViewStep::jobs() const
{
    return JobList();
}

void
ExecutionViewStep::appendJobModuleInstanceKey( const ModuleSystem::InstanceKey& instanceKey )
{
    m_jobInstanceKeys.append( instanceKey );
}

void
ExecutionViewStep::updateFromJobQueue( qreal percent, const QString& message )
{
    m_progressBar->setValue( int( percent * m_progressBar->maximum() ) );
    if ( !message.isEmpty() )
    {
        m_label->setText( message );
    }
    static_cast<CoreVaultExecutionSurface*>(m_widget)->arrange();
}

void
ExecutionViewStep::toggleLog()
{
    // The minimal installation screen has no technical-log control.
    m_tab_widget->hide();
}

void
ExecutionViewStep::onLeave()
{
    m_log_widget->stop();
    m_slideshow->changeSlideShowState( Slideshow::Stop );
}

}  // namespace Calamares
