# Bitcoin Core Vault native Thunar permanent deletion

The upstream application is Debian Thunar 4.20.2-1+deb13u1. The local package
replaces the native Move to Trash menu with Permanently Delete and routes native
trash/delete actions, Delete, Shift+Delete, tree-view and D-Bus deletion through
/usr/local/bin/core-vault-shred. Its GUI confirmation and filesystem checks are
owned by the separate Vault runtime helper. No ordinary delete fallback exists.
Copy, move, rename, extension ABI, official translations and other package files
remain unchanged. Permanent deletion is not added to the Undo operation log.

The complete corresponding source, official Debian original source/DSC/patches,
native patch, exact dependency manifest and build recipes are included here.
The original archives match Debian's authenticated APT Sources checksums. The
official base binary package and private dependency downloads match APT hashes.

To reproduce on Debian 13 amd64 with GCC, make, dpkg-dev and the standard XFCE
runtime libraries installed:
1. python3 prepare-private-prefix.py deps-manifest.json PRIVATE_BUILD_DIRECTORY
2. tar -xJf Thunar-core-vault-source.tar.xz into a new source directory
3. python3 build-thunar.py Thunar-core-vault-source PRIVATE_BUILD_DIRECTORY/prefix
4. python3 test-dispatch.py Thunar-core-vault-source PRIVATE_BUILD_DIRECTORY/prefix TEST_OUTPUT
5. strip --strip-unneeded Thunar-core-vault-source/thunar/.libs/thunar

The source archive is already patched; do not apply the patch again.
The private build prefix is used only for compilation. No private libraries are
installed in Vault and the executable has no private RPATH/RUNPATH.
This package modifies Vault image inputs, never the host's installed Thunar.
