-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: thunar
Binary: libthunarx-3-dev, libthunarx-3-0, gir1.2-thunarx-3.0, thunar, thunar-data
Architecture: any all
Version: 4.20.2-1+deb13u1
Maintainer: Debian Xfce Maintainers <debian-xfce@lists.debian.org>
Uploaders: Yves-Alexis Perez <corsac@debian.org>
Homepage: https://docs.xfce.org/xfce/thunar/start
Standards-Version: 4.7.0
Vcs-Browser: https://salsa.debian.org/xfce-team/desktop/thunar
Vcs-Git: https://salsa.debian.org/xfce-team/desktop/thunar.git
Build-Depends: debhelper-compat (= 13), gettext, gobject-introspection, gtk-doc-tools, libgirepository1.0-dev, libexif-dev, libexo-2-dev (>= 4.19.0), libglib2.0-dev, libgtk-3-dev, libgudev-1.0-dev [linux-any], libjpeg-dev, libnotify-dev, libpcre2-dev, libtool, libxfce4panel-2.0-dev, libxfce4ui-2-dev (>= 4.17.6), libxfce4util-dev (>= 4.17.2), libxfconf-0-dev, xfce4-dev-tools
Package-List:
 gir1.2-thunarx-3.0 deb introspection optional arch=any
 libthunarx-3-0 deb libs optional arch=any
 libthunarx-3-dev deb libdevel optional arch=any
 thunar deb xfce optional arch=any
 thunar-data deb xfce optional arch=all
Checksums-Sha1:
 d7101026b02c3dcc9810122a2f3df84ab680efc7 4452492 thunar_4.20.2.orig.tar.bz2
 3e54b8d97ac3c4bf854a479455f8b06e1fec2368 16520 thunar_4.20.2-1+deb13u1.debian.tar.xz
Checksums-Sha256:
 71376f6d7ba4998943c412f374db16ec9b709610acd4d27ecb1eef3aca82af05 4452492 thunar_4.20.2.orig.tar.bz2
 dbca892cd73420dd2446c3194af52181053978fa053ef4fcd63e80457164cd63 16520 thunar_4.20.2-1+deb13u1.debian.tar.xz
Files:
 87adf363ea5f93d7f7ab55ad384ff74e 4452492 thunar_4.20.2.orig.tar.bz2
 45c2ce3f07346b5ee39e138addaee2bb 16520 thunar_4.20.2-1+deb13u1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQEzBAEBCgAdFiEE8vi34Qgfo83x35gF3rYcyPpXRFsFAmisH2gACgkQ3rYcyPpX
RFvcwQf8DH0YkyLGUKunkCa1f3XovgKcZY5NGw+exs+iKP8U0/lKYz/LHmd/hFT5
SQPHZ9XCZfT3Mm/U1Wpj1pHLjz9fJIKMdd9LTJ8JIM4L8LG+rrcP0txg902RzcfB
9elcJbPn0sLspu31NUP1EFcciw6Em/MPoh0VIvkznQlwj+LlrrEsOn59x8+DBfse
lpIe8jpw8Xp1CA659sfngzErV1JagHDbJMPeWea7rpNJjBwB7iTBV7ZrAeUTw7HO
hHaOXKZsEoMfv0Zht2gVJUByN0vBUUz2dsHwiGyp6Qv0HjopSj/T/vubu9hbcUgh
lMCBBzq2BNZd5A7+FxsPhbQQgzH0YQ==
=ulZf
-----END PGP SIGNATURE-----
