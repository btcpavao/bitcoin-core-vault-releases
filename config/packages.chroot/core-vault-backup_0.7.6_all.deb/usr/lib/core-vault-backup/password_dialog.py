#!/usr/bin/python3
"""Shared Qt passphrase controls. Secrets never leave the current process."""
from pathlib import Path
import os
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QFileDialog,
    QFrame, QHBoxLayout, QLabel, QLineEdit, QListView, QPushButton, QScrollArea,
    QStyle, QStyleOptionComboBox, QVBoxLayout, QWidget)
from destinations import backup_output_path, destination_directory, mounted_usb_volumes, recovery_destination
from layered_backend import MAX_LAYERS

STYLE = """
QDialog, QScrollArea, QWidget#layers { background:#111111; color:#f2f2f2; }
QScrollArea { border:0; }
QLabel { color:#f2f2f2; background:transparent; }
QLabel#heading { font-size:22px; font-weight:600; }
QLabel#note, QLabel#status { color:#c5c5c5; }
QLineEdit, QComboBox { color:white; background:#202020; border:1px solid #626262;
 border-radius:5px; padding:9px; min-height:22px; selection-background-color:#2468a2; }
QLineEdit:focus { border:2px solid #589ddd; padding:8px; }
QComboBox { combobox-popup:0; padding:9px 34px 9px 11px; }
QComboBox:hover { border-color:#a0a0a0; }
QComboBox:focus, QComboBox:on { border:2px solid #589ddd; padding:8px 33px 8px 10px; }
QComboBox::drop-down { subcontrol-origin:border; width:34px; border:0; background:transparent; }
QComboBox::down-arrow { image:none; width:0px; height:0px; }
QComboBoxPrivateContainer { background:#202020; border:0; padding:0; }
QComboBox QAbstractItemView { color:#f2f2f2; background:#202020; border:1px solid #626262;
 padding:3px; outline:0; selection-color:white; selection-background-color:#2468a2; }
QComboBox QAbstractItemView::item { min-height:30px; padding:0 8px; color:#f2f2f2; background:#202020; }
QComboBox QAbstractItemView::item:hover { background:#383838; }
QComboBox QAbstractItemView::item:selected { color:white; background:#2468a2; }
QCheckBox { color:#f2f2f2; spacing:8px; padding:5px 0; }
QCheckBox::indicator { width:18px; height:18px; }
QPushButton { color:#eee; background:#242424; border:1px solid #626262;
 border-radius:6px; padding:9px 14px; }
QPushButton:hover { border-color:#a0a0a0; }
QPushButton:focus { border:2px solid #8fbee8; padding:8px 13px; }
QPushButton#create { background:#2169a8; border-color:#438fcf; color:white; }
QPushButton:disabled, QPushButton#create:disabled { background:#262626; color:#888; border-color:#424242; }
"""

def label(text, name=None):
    result = QLabel(str(text))
    result.setTextFormat(Qt.TextFormat.PlainText)
    result.setWordWrap(True)
    if name:
        result.setObjectName(name)
    return result


class SecretEdit(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.on_return = None
        self.setEchoMode(QLineEdit.EchoMode.Password)
        self.setInputMethodHints(Qt.InputMethodHint.ImhSensitiveData | Qt.InputMethodHint.ImhNoPredictiveText)
        self.setDragEnabled(False)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            event.accept()
            if self.on_return:
                self.on_return()
            return
        super().keyPressEvent(event)


class DestinationList(QComboBox):
    opening = Signal()

    def __init__(self):
        super().__init__()
        self.setView(QListView())

    def paintEvent(self, event):
        super().paintEvent(event)
        option = QStyleOptionComboBox()
        self.initStyleOption(option)
        arrow = self.style().subControlRect(QStyle.ComplexControl.CC_ComboBox, option,
                                            QStyle.SubControl.SC_ComboBoxArrow, self)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.translate(arrow.center())
        if self.view().isVisible():
            painter.scale(1, -1)
        painter.setPen(QPen(QColor('#e8e8e8'), 2, Qt.PenStyle.SolidLine,
                            Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        chevron = QPainterPath()
        chevron.moveTo(-5, -2)
        chevron.lineTo(0, 3)
        chevron.lineTo(5, -2)
        painter.drawPath(chevron)
        painter.end()

    def showPopup(self):
        self.opening.emit()
        super().showPopup()


class SecretRow(QWidget):
    def __init__(self, owner, confirm):
        super().__init__()
        self.owner = owner
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 6, 0, 14)
        layout.setSpacing(8)
        heading = QHBoxLayout()
        self.title = label('')
        self.remove = QPushButton('Remove')
        self.remove.setAutoDefault(False)
        self.remove.clicked.connect(lambda: owner.remove_row(self))
        heading.addWidget(self.title, 1)
        heading.addWidget(self.remove)
        layout.addLayout(heading)
        self.password = SecretEdit()
        self.confirm = SecretEdit() if confirm else None
        self.title.setBuddy(self.password)
        layout.addWidget(self.password)
        self.password.textChanged.connect(owner.update_validation)
        if self.confirm is not None:
            confirmation_label = label('Confirm')
            confirmation_label.setBuddy(self.confirm)
            layout.addWidget(confirmation_label)
            layout.addWidget(self.confirm)
            self.confirm.textChanged.connect(owner.update_validation)
        self.show_secret = QCheckBox('Show')
        self.show_secret.toggled.connect(self.toggle_visibility)
        layout.addWidget(self.show_secret)
        if self.confirm:
            self.password.on_return = lambda: self.confirm.setFocus(Qt.FocusReason.TabFocusReason)
        self.password.setAccessibleName('Passphrase')

    def toggle_visibility(self, visible):
        for edit in (self.password, self.confirm):
            if edit is not None:
                pos = edit.cursorPosition()
                edit.setEchoMode(QLineEdit.EchoMode.Normal if visible else QLineEdit.EchoMode.Password)
                edit.setCursorPosition(pos)

    def clear(self):
        for edit in (self.password, self.confirm):
            if edit is not None:
                edit.blockSignals(True)
                edit.setEchoMode(QLineEdit.EchoMode.Password)
                edit.clear()
                edit.blockSignals(False)
        self.show_secret.setChecked(False)


class PassphraseDialog(QDialog):
    def __init__(self, validator, parent=None, *, destination=None, items=(),
                 recovery=False, workspace=None, previous=(), error='', secrets_only=False):
        super().__init__(parent)
        self.validator, self.recovery = validator, recovery
        self.workspace = (Path(workspace) if workspace is not None else
                          Path(destination).parent if destination is not None else None)
        self.payload_suffix = ('.dat' if len(items) == 1 and
            Path(items[0]).name == 'wallet.dat' and Path(items[0]).is_file()
            else '.tar')
        self.secrets_only = secrets_only
        self.value = self.destination_value = None
        self.checked_destination = None
        self.destination_error = ''
        self.rows = []
        self.setWindowTitle('Decrypt Encrypted Backup' if recovery else 'Create Encrypted Backup')
        self.setStyleSheet(STYLE)
        self.resize(680, 690)
        screen = QApplication.primaryScreen()
        if screen:
            size = screen.availableGeometry().size()
            self.resize(min(680, size.width() - 32), min(690, size.height() - 48))
        self.setMinimumSize(440, 400)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(12)
        outer.addWidget(label(self.windowTitle(), 'heading'))
        if items:
            selected = label('Selected: ' + ', '.join(Path(p).name for p in items[:4]) +
                             (' …' if len(items) > 4 else ''), 'note')
            selected.setToolTip('\n'.join(map(str, items)))
            outer.addWidget(selected)
        outer.addWidget(label(('Enter the available backup passphrases in any order.'
            if recovery else 'Generate a separate random passphrase for each layer with KeePassXC. Keep each secret separately from the backup.'), 'note'))
        if error:
            outer.addWidget(label(error, 'status'))
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.panel = QWidget()
        self.panel.setObjectName('layers')
        self.rows_layout = QVBoxLayout(self.panel)
        self.rows_layout.setContentsMargins(0, 0, 12, 0)
        self.rows_layout.setSpacing(8)
        self.rows_layout.addStretch(1)
        self.scroll.setWidget(self.panel)
        outer.addWidget(self.scroll, 1)
        self.add_button = QPushButton('+ Add Passphrase' if recovery else '+ Add Encryption Layer')
        self.add_button.setAutoDefault(False)
        self.add_button.clicked.connect(lambda: self.add_row(focus=True))
        outer.addWidget(self.add_button, 0, Qt.AlignmentFlag.AlignLeft)
        self.ordinary = None
        if recovery and not secrets_only:
            self.ordinary = QCheckBox('Recover one ordinary GPG layer only')
            self.ordinary.setToolTip('For files made outside Vault. Saves one authenticated payload as recovered-file without guessing nested layers or extracting archives.')
            outer.addWidget(self.ordinary)
        self.destination = None
        self.locations = None
        if not secrets_only:
            suggested = Path(destination or 'recovered-backup')
            if recovery and not suggested.is_absolute():
                suggested = self.workspace / suggested
            self.destination = QLineEdit(str(suggested))
            self.destination.setAccessibleName('New recovery folder' if recovery else 'Save backup as')
            location_row = QHBoxLayout()
            location_caption = label('Recover to' if recovery else 'Save to')
            self.locations = DestinationList()
            self.locations.setPlaceholderText('Other folder')
            self.locations.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            self.locations.setMinimumContentsLength(16)
            self.locations.setAccessibleName('Recovery location' if recovery else 'Backup location')
            location_caption.setBuddy(self.locations)
            location_row.addWidget(location_caption)
            location_row.addWidget(self.locations, 1)
            outer.addLayout(location_row)
            self.locations.opening.connect(self.refresh_locations)
            self.locations.activated.connect(self.select_location)
            self.media_note = label('', 'note')
            outer.addWidget(self.media_note)
            self.refresh_locations()
            caption = label('New recovery folder' if recovery else 'Save backup as')
            caption.setBuddy(self.destination)
            outer.addWidget(caption)
            row = QHBoxLayout()
            row.addWidget(self.destination, 1)
            self.choose_destination = QPushButton('Choose…')
            self.choose_destination.setAutoDefault(False)
            self.choose_destination.clicked.connect(self.choose_location)
            row.addWidget(self.choose_destination)
            outer.addLayout(row)
            self.destination.textChanged.connect(self.update_destination)
        self.status = label('', 'status')
        outer.addWidget(self.status)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.cancel_button = QPushButton('Cancel')
        self.create_button = QPushButton('Verify Backup' if secrets_only else
                                        'Decrypt Backup' if recovery else 'Create Encrypted Backup')
        self.create_button.setObjectName('create')
        for button in (self.cancel_button, self.create_button):
            button.setAutoDefault(False)
            button.setDefault(False)
            buttons.addWidget(button)
        outer.addLayout(buttons)
        self.cancel_button.clicked.connect(self.reject)
        self.create_button.clicked.connect(self.accept)
        for value in previous or ('',):
            row = self.add_row()
            row.password.setText(value)
        self.rows[0].password.setFocus(Qt.FocusReason.OtherFocusReason)
        self.update_destination()

    def add_row(self, focus=False):
        if len(self.rows) >= MAX_LAYERS:
            return None
        row = SecretRow(self, not self.recovery)
        self.rows.append(row)
        self.rows_layout.insertWidget(len(self.rows) - 1, row)
        self.renumber()
        self.update_validation()
        if focus:
            row.password.setFocus(Qt.FocusReason.TabFocusReason)
            QTimer.singleShot(0, lambda: self.scroll.ensureWidgetVisible(row))
        return row

    def remove_row(self, row):
        if len(self.rows) == 1:
            return
        index = self.rows.index(row)
        self.rows.remove(row)
        row.clear()
        self.rows_layout.removeWidget(row)
        row.deleteLater()
        self.renumber()
        self.rows[min(index, len(self.rows) - 1)].password.setFocus()
        self.update_validation()

    def renumber(self):
        for i, row in enumerate(self.rows, 1):
            title = 'Passphrase' if len(self.rows) == 1 else 'Passphrase ' + str(i)
            row.title.setText(title)
            row.password.setAccessibleName(title)
            row.show_secret.setAccessibleName('Show ' + title.lower())
            if row.confirm:
                row.confirm.setAccessibleName('Confirm ' + title.lower())
            row.remove.setAccessibleName('Remove ' + title.lower())
            row.remove.setVisible(len(self.rows) > 1)
        self.add_button.setEnabled(len(self.rows) < MAX_LAYERS)
        # Show the actual portable filename immediately when adding/removing
        # encryption layers. Every .gpg suffix corresponds to one layer.
        if not self.recovery and self.destination is not None:
            self.destination.setText(str(self.backup_name(self.destination.text())))

    def backup_name(self, text):
        """A GUI which strips one .gpg suffix per decrypt can recover all layers.

        Keep the supplied directory and base name; append the payload suffix and one
        .gpg per layer. This also works when the UI ignores embedded filenames.
        """
        base = text
        while base.lower().endswith('.gpg'):
            base = base[:-4]
        for suffix in ('.tar', '.dat'):
            if base.lower().endswith(suffix):
                base = base[:-len(suffix)]
                break
        base += self.payload_suffix
        return Path(base + '.gpg' * len(self.rows))

    def normalized_destination(self):
        if self.secrets_only:
            return None
        text = self.destination.text()
        if not text or any(ord(c) < 32 or ord(c) == 127 for c in text):
            raise ValueError('Please choose a valid destination name.')
        path = Path(text)
        if self.recovery:
            if not path.is_absolute():
                if text in ('.', '..') or '/' in text or '\\' in text:
                    raise ValueError('Please use a folder name or an absolute recovery path.')
                path = self.workspace / text
            path = recovery_destination(path, self.workspace)
        else:
            if not path.is_absolute():
                raise ValueError('Please choose an absolute backup location.')
            path = backup_output_path(self.backup_name(text))
            try:
                with destination_directory(path.parent):
                    pass
            except OSError:
                raise ValueError('Please select an existing, writable destination folder.') from None
        if os.path.lexists(path):
            raise ValueError('That destination exists. Please choose a new name.')
        return path

    def refresh_locations(self):
        self.locations.clear()
        self.locations.addItem('Private Workspace', str(self.workspace))
        self.locations.setItemData(0, 'Temporary storage in RAM', Qt.ItemDataRole.ToolTipRole)
        for volume in mounted_usb_volumes():
            self.locations.addItem(f'USB: {volume.name} ({volume})', str(volume))
            self.locations.setItemData(self.locations.count() - 1, str(volume), Qt.ItemDataRole.ToolTipRole)
        if hasattr(self, 'status'):
            self.update_destination()
        else:
            self.sync_location(Path(self.destination.text()))

    def sync_location(self, path):
        if not path.is_absolute():
            path = self.workspace / path if self.recovery else path
        index = next((i for i in range(self.locations.count())
                      if path.is_relative_to(Path(self.locations.itemData(i)))), -1)
        self.locations.setCurrentIndex(index)
        self.locations.setToolTip(self.locations.currentData(Qt.ItemDataRole.ToolTipRole) or '')
        self.media_note.setText(('Recovered files will be written to this drive without GPG protection. '
                                 'Interrupting the copy can leave plaintext on the drive.')
                                if self.recovery else 'The encrypted backup will be saved on this USB drive.')
        external_recovery = (self.recovery and self.checked_destination is not None and
                             self.checked_destination.parent != self.workspace)
        self.media_note.setVisible(index > 0 or external_recovery)

    def select_location(self, index):
        parent = self.locations.itemData(index)
        if parent:
            name = Path(self.destination.text()).name or ('recovered-backup' if self.recovery else 'backup')
            self.destination.setText(str(Path(parent) / name))

    def choose_location(self):
        current = Path(self.destination.text())
        if self.recovery:
            folder = QFileDialog.getExistingDirectory(self, 'Choose the parent for the new recovery folder',
                                                       str(current.parent if current.is_absolute() else self.workspace))
            selected = str(Path(folder) / (current.name or 'recovered-backup')) if folder else ''
        else:
            selected, _ = QFileDialog.getSaveFileName(self, 'Save encrypted backup', str(current),
                'GPG backup (*.gpg)', options=QFileDialog.Option.DontConfirmOverwrite)
        if selected:
            self.refresh_locations()
            self.destination.setText(selected)

    def update_destination(self, *_):
        # Probing the selected drive can invoke findmnt/lsblk. Recheck on path
        # changes and on submit, without probing for every passphrase keystroke.
        self.destination_error = ''
        try:
            self.checked_destination = self.normalized_destination()
        except ValueError as exc:
            self.checked_destination = None
            self.destination_error = str(exc)
        if self.locations is not None:
            self.sync_location(self.checked_destination or Path(self.destination.text()))
        self.update_validation()

    def update_validation(self, *_):
        if not hasattr(self, 'status'):
            return
        error, values = '', [row.password.text() for row in self.rows]
        try:
            if self.destination_error:
                raise ValueError(self.destination_error)
            for row in self.rows:
                self.validator(row.password.text())
                if row.confirm and row.password.text() != row.confirm.text():
                    raise ValueError('Please enter matching passphrases in each layer.')
            if len(set(values)) != len(values):
                raise ValueError('Please use a different passphrase for each layer.')
        except ValueError as exc:
            error = str(exc)
        valid = bool(values) and not error
        self.create_button.setEnabled(valid)
        self.status.setText(error or ('Ready. All required backup passphrases must remain available for recovery.'
                                    if self.recovery else 'Ready to create and verify every encryption layer.'))

    def accept(self):
        self.update_destination()
        if not self.create_button.isEnabled():
            return
        self.value = [row.password.text() for row in self.rows]
        self.destination_value = self.checked_destination
        self.clear_fields()
        super().accept()

    def clear_fields(self):
        # UI cleanup only. Python/Qt memory erasure is not guaranteed.
        for row in self.rows:
            row.clear()

    def reject(self):
        self.value = self.destination_value = None
        self.clear_fields()
        super().reject()


_APPLICATION = None

def ensure_app():
    global _APPLICATION
    _APPLICATION = QApplication.instance() or _APPLICATION or QApplication(['core-vault-backup'])
    _APPLICATION.setStyle('Fusion')
    _APPLICATION.setFont(QFont('DejaVu Sans', 10))
    return _APPLICATION


def get_backup_request(validator, destination, *, items=()):
    ensure_app()
    window = PassphraseDialog(validator, destination=Path(destination), items=items)
    result = window.exec()
    value = (window.destination_value, window.value) if result == QDialog.DialogCode.Accepted else None
    window.value = None
    window.clear_fields()
    window.deleteLater()
    return value


def get_verification_secrets(validator, archive):
    ensure_app()
    window = PassphraseDialog(validator, items=[archive], recovery=True, secrets_only=True)
    result = window.exec()
    value = window.value if result == QDialog.DialogCode.Accepted else None
    window.value = None
    window.clear_fields()
    window.deleteLater()
    return value
